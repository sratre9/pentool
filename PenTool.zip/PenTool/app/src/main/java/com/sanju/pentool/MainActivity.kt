package com.sanju.pentool

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import java.io.OutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermRequest: PermissionRequest? = null
    private var out: OutputStream? = null
    private var outUri: Uri? = null

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            val uris: Array<Uri>? =
                if (r.resultCode == RESULT_OK && data != null)
                    WebChromeClient.FileChooserParams.parseResult(r.resultCode, data)
                else null
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    private val askMic =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val req = pendingPermRequest
            pendingPermRequest = null
            if (req != null) {
                if (granted) req.grant(req.resources) else req.deny()
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Fullscreen (immersive) + keep screen on
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
        }
        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = WebViewClient()

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
                        val ok = ContextCompat.checkSelfPermission(
                            this@MainActivity, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (ok) {
                            request.grant(request.resources)
                        } else {
                            pendingPermRequest = request
                            askMic.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    } else {
                        request.deny()
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES, arrayOf(
                            "application/pdf",
                            "image/*",
                            "video/*",
                            "application/vnd.ms-powerpoint",
                            "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                        )
                    )
                }
                return try {
                    pickFile.launch(intent)
                    true
                } catch (e: Exception) {
                    filePathCallback = null
                    false
                }
            }
        }

        val html = try {
            assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "<h3>index.html not found: " + e.message + "</h3>"
        }
        web.loadDataWithBaseURL("https://pentool.app/", html, "text/html", "UTF-8", null)
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    /** Called from JavaScript to save the recorded video into Movies/PenTool. */
    inner class Bridge {
        @JavascriptInterface
        fun saveChunk(b64: String, name: String, first: Boolean) {
            try {
                if (first) {
                    out?.close()
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                        put(
                            MediaStore.Video.Media.MIME_TYPE,
                            if (name.endsWith(".mp4")) "video/mp4" else "video/webm"
                        )
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PenTool")
                        put(MediaStore.Video.Media.IS_PENDING, 1)
                    }
                    outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                    out = outUri?.let { contentResolver.openOutputStream(it) }
                }
                out?.write(Base64.decode(b64, Base64.DEFAULT))
            } catch (e: Exception) {
                toast("वीडियो सेव नहीं हो पाया")
            }
        }

        @JavascriptInterface
        fun saveImage(b64: String, name: String) {
            try {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PenTool")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
                contentResolver.openOutputStream(uri!!)?.use { it.write(Base64.decode(b64, Base64.DEFAULT)) }
                toast("फ़ोटो सेव हो गई: Pictures/PenTool")
            } catch (e: Exception) {
                toast("फ़ोटो सेव नहीं हो पाई")
            }
        }

        @JavascriptInterface
        fun saveDone(name: String) {
            try {
                out?.close()
                out = null
                outUri?.let {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    contentResolver.update(it, v, null, null)
                }
                toast("वीडियो सेव हो गया: Movies/PenTool")
            } catch (e: Exception) {
                toast("वीडियो सेव नहीं हो पाया")
            }
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
